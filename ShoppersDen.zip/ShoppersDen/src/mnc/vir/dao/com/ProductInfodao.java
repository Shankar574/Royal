package mnc.vir.dao.com;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.bean.Product;
import mnc.vir.utility.OnlineDatabase;


public class ProductInfodao {

	public ArrayList get(String s) {
		 Logger log=Logger.getLogger(ProductInfodao.class);
			PropertyConfigurator.configure("log4j.properties");
		
	ResultSet r=null;
	ArrayList<Product> al=null;
		try{
			System.out.println(s);
			al=new ArrayList<Product>();
			  Connection con=OnlineDatabase.getConnection();	
			  log.info("dao"+s);
			  PreparedStatement p =
			  con.prepareStatement("select * from product where ptype=?");
			  p.setString(1, s);
			  r = p.executeQuery();
			  while (r.next()) {
				Product pro = new Product();
	            String id = r.getString(1);
	            String type = r.getString(2);
	            int cost = r.getInt(3);
	         	pro.setPid(id);
	            pro.setPtype(type);
	            pro.setCost(cost);
	            al.add(pro);
	             }
			}catch(Exception e){
		log.fatal(e);
	}
		return al;
		
}
}