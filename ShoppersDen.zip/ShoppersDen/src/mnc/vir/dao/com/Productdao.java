package mnc.vir.dao.com;




import java.sql.Connection;

import java.sql.PreparedStatement;






import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.utility.OnlineDatabase;

public class Productdao {
	OnlineDatabase odb  = OnlineDatabase.getObject();
	Connection con;

	public int insert(String i1,String s2,int i2) {
		 Logger log=Logger.getLogger(Productdao.class);
			PropertyConfigurator.configure("log4j.properties");
		int r=0;
		
		try{
			log.info(i1);
			log.info(i2);
			Connection con=OnlineDatabase.getConnection();	
			PreparedStatement p = con.prepareStatement("insert into product values(?,?,?)");
			p.setString(1,i1); 
			p.setString(2, s2);
			p.setInt(3, i2);
			r=p.executeUpdate(); 
			if(r==0){ 
				 log.info("No Query executed");
			
				 }
			  else 
				  log.info("Query Executed");
				  }
		catch(Exception e){
			log.fatal(e);
		}
		return r;



}
}