package mnc.vir.dao.com;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.bean.Admin;

import mnc.vir.utility.OnlineDatabase;

public class Admindao {
	
	


	private static Connection con;
	 PreparedStatement p;
	
	
	
	public int insertAdmin(Admin a) throws ClassNotFoundException, SQLException {
		Logger log=Logger.getLogger(Admindao.class);
		PropertyConfigurator.configure("log4j.properties");
		int r=0;
		
			 con = OnlineDatabase.getConnection();
			 Statement st=con.createStatement();
			 ResultSet rs=st.executeQuery("select count(*) from admin");
			 
			 int r1=0;
			 int adminId=0;
			 
					  if(rs.next()) {
						 adminId=rs.getInt(1)+1; 
					  }
					  
			  p = con.prepareStatement("insert into admin values(?,?,?,?,?)");
			  log.info(adminId);
			  p.setInt(1, adminId);
			  p.setString(2, a.getName().toLowerCase()); 
			  p.setString(3, a.getPassword().toLowerCase()); 
			  p.setString(4, a.getEmail());
			  p.setLong(5, a.getMobile());
			  
			  r1=p.executeUpdate();
			  log.info(r1);
		
			  
			 if(r1==0) {
				log.warn("No Query Executed");
			  r = 0;
			 }
			  else { 
				  log.info("Query Executed");
				
				  r = 1;
			  }
			  
			 
		return r;
	

	}

	 public int adminSignin(String s1,String s2) throws SQLException, ClassNotFoundException {
		 Logger log=Logger.getLogger(Admindao.class);
			PropertyConfigurator.configure("log4j.properties");
			int i=0;
			log.info(s1);
			log.info(s2);
			con = OnlineDatabase.getConnection();		
			 PreparedStatement ps = con.prepareStatement("select * from admin where name=? and password=?");
			  
			  ps.setString(1,s1.toLowerCase()); 
			  ps.setString(2,s2.toLowerCase());
			 
				ResultSet r = ps.executeQuery();
				if(r.next()){
					i=1;
				}
			
		
			return i;
			
	}
}


