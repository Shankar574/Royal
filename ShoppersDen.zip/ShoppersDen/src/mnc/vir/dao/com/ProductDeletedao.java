package mnc.vir.dao.com;




import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.utility.OnlineDatabase;

public class ProductDeletedao {
	public int delete(String s1) throws SQLException, ClassNotFoundException {
		 Logger log=Logger.getLogger(ProductDeletedao.class);
			PropertyConfigurator.configure("log4j.properties");
		int count=0;
		Connection con;
		con = OnlineDatabase.getConnection();
		System.out.println(s1);
		PreparedStatement p =
		con.prepareStatement("delete from product where PID=?");
		p.setString(1,s1); 
			 
			 count=p.executeUpdate(); 
			 if(count==0){ log.warn("no query excuted"); }
			  else
				  log.info("Query Executed");
		
			  
		return count;



  }
}
