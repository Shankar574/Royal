package mnc.vir.dao.com;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.bean.Customer;
import mnc.vir.utility.OnlineDatabase;

public class Customerdao {
	
	 
	OnlineDatabase odb  = OnlineDatabase.getObject();
	Connection con;
	PreparedStatement p;
	Customer c=null;
	public int insert(Customer c) {
		 Logger log=Logger.getLogger(Customerdao.class);
		 PropertyConfigurator.configure("log4j.properties");	
		 int r=0;
			try{
				
				  
				  con = OnlineDatabase.getConnection();	
				  PreparedStatement p =
				  con.prepareStatement("insert into customer values(?,?,?,?,?,?)");
				  p.setString(1, c.getName()); 
				  System.out.println("...............................");
				  p.setString(2, c.getEmail());
				  p.setDouble(3, c.getMobile());
				  p.setString(4, c.getAddr());
				  p.setString(5, c.getUserid()); 
				  p.setString(6, c.getPassword()); 
				  r=p.executeUpdate(); 
				  if(r==0){ log.warn("no query excuted"); }
				   else log.info("query excuted");
				  
				 
			
		}catch(java.sql.SQLIntegrityConstraintViolationException e){
			r=3;
			log.fatal(e);
		}
			catch(Exception e){
				log.fatal(e);
			}
			return r;

		}
	 public Customer get(String s) {
		Logger log=Logger.getLogger(Customerdao.class);
		PropertyConfigurator.configure("log4j.properties");
		
		Customer c=null;
		try{
			 c=new Customer();
			 con=OnlineDatabase.getConnection();	
			 log.info(s);
			 PreparedStatement p = con.prepareStatement("select * from customer where name=?");
			 p.setString(1, s);
			 ResultSet r = p.executeQuery();
			 if (r.next()) {
				c.setUserid(r.getString(5));
				c.setAddr(r.getString(4));
				c.setEmail(r.getString(2));
				c.setName(r.getString(1));
				c.setPassword(r.getString(6));
				c.setMobile(r.getDouble(3));
			}
			 
		
	}catch(Exception e){
		log.fatal(e);
		
	}
		return c;
		

	}

	
	 public int signin(String s1,String s2) throws SQLException, ClassNotFoundException {
		   Logger log=Logger.getLogger(Customerdao.class);
			PropertyConfigurator.configure("log4j.properties");
			int i=0;
			try{
				log.info(s1);
				log.info(s2);
				con = OnlineDatabase.getConnection();		
				PreparedStatement p = con.prepareStatement("select * from customer where name=? and password=?");
				p.setString(1,s1); p.setString(2, s2);
				ResultSet r = p.executeQuery();
				if(r.next()){
					i =1;
				}
			
		}catch(Exception e){
		
			log.fatal(e);
		}
			return i;
			
		}
	}
		


	
	
	

	

