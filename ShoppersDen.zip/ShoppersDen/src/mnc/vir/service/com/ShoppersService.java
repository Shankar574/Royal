package mnc.vir.service.com;


import java.sql.SQLException;

import mnc.vir.bean.Admin;
import mnc.vir.bean.Customer;
import mnc.vir.dao.com.Admindao;
import mnc.vir.dao.com.Customerdao;
import mnc.vir.dao.com.ProductDeletedao;
import mnc.vir.dao.com.Productdao;

public class ShoppersService {
	Customerdao cd=new Customerdao(); 
	Admindao d=new Admindao();
	ProductDeletedao pd=new ProductDeletedao();
	Productdao po=new Productdao();
	public int signin(String s1, String s2) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return cd.signin(s1, s2);
		
	}
	public int adminSignin(String s1, String s2) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return d.adminSignin(s1, s2);
		
	}

	public int insertAdmin(Admin ad) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return d.insertAdmin(ad);
	}

	public int delete(String s1) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		return pd.delete(s1);
	}

	
	public int insert(Customer c) {
		// TODO Auto-generated method stub
		return cd.insert(c);
	}

	
		public int insert(String s1, String s2, int i2) {
		// TODO Auto-generated method stub
		return po.insert(s1, s2, i2);
	}
	
	

}
