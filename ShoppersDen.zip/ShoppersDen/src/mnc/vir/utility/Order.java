package mnc.vir.utility;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import mnc.vir.bean.Item;

public class Order implements Serializable{
	
	private ArrayList<Item> list;
	
	@Override
	public String toString() {
		return "Order [list=" + list + "]";
	}

		 
	public Order(){
		list=new ArrayList<Item>();
	}
	
	 
	public void addProduct(Item i){
		 list.add(i);
	
	}//addProduct
	 
	public boolean removeProduct(Item i)
	   {
return list.remove(i);
	
	
	}
	 
	public Collection getCartDetails(){
	return list;
	}
	 
	
	 
	public int productCount(){
	return list.size();
	}
	 
	  public double getCartPrice() {
	    double price = 0.0d;
	    Iterator iterator = getCartDetails().iterator();
	    while(iterator.hasNext()){
	      price+= ((Item) iterator.next()).getCost();
	    }
	    return price;
	  }
	}


