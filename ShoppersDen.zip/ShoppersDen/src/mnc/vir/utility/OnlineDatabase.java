package mnc.vir.utility;

import java.sql.DriverManager;
import java.sql.Connection;



import java.sql.SQLException;






public class OnlineDatabase {
	
	private static OnlineDatabase odb = null;
	Connection con = null;
	

	private OnlineDatabase() {
		
	}
	
	public static OnlineDatabase getObject() {

		
		if(odb==null)
			return odb = new OnlineDatabase();
		
		return odb;
	}
	
	public static Connection getConnection()throws SQLException,ClassNotFoundException{

		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
		
		return con;
	}
	
	
	

	
	

	
}
