package mnc.vir.controller.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import mnc.vir.service.com.ShoppersService;

public class AdminLoginController extends HttpServlet {
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Logger log=Logger.getLogger(AdminLoginController.class);
		PropertyConfigurator.configure("log4j.properties");
		 PrintWriter p=res.getWriter();
		 res.setContentType("text/html");
		 ShoppersService ss=new ShoppersService();
		 String s1=req.getParameter("Adminname");
		 String s2=req.getParameter("Adminpassword");
		
	try {
		if(ss.adminSignin(s1, s2)==1) {
			
		    	RequestDispatcher r=req.getRequestDispatcher("adminlinks.jsp");
		    	log.info("Login Sucessfull");
		    	r.forward(req, res);
		}
		else {
			p.println("<b style='color:red'>Invaliad Admin Name and Password</b>");
			RequestDispatcher r=req.getRequestDispatcher("AdminLogin.jsp")	;
			log.info("Login failed");
		   	r.include(req, res);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		log.fatal(e);
	}
   		

		
	}
}
