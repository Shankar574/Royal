package mnc.vir.controller.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.bean.Admin;


import mnc.vir.service.com.ShoppersService;



public class AdminRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Logger log=Logger.getLogger(AdminRegisterController.class);
		PropertyConfigurator.configure("log4j.properties");
		PrintWriter p = res.getWriter();
		Admin ad = new Admin();
		ShoppersService ss=new ShoppersService();
		res.setContentType("text/html");
		String name=	req.getParameter("name");
		String email =	req.getParameter("email");
		long mobile = Long.parseLong(req.getParameter("mobile"));
		String pwd =req.getParameter("password");
			ad.setName(name);			
			ad.setEmail(email);
			ad.setMobile(mobile);
			ad.setPassword(pwd);
			int b = 0;
			try {
				b = ss.insertAdmin(ad);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				log.fatal(e);
				
			}
			
			if (b==1){
				
			    RequestDispatcher r=req.getRequestDispatcher("adminlogin.html");
			    p.println("Admin Registered sucessfully");
			    r.include(req, res);
			}
			else if(b==3){
				log.info("Not inserted");
				p.println("This user Id already Exists ");
				RequestDispatcher r=req.getRequestDispatcher("AdminRegister.html");
				r.include(req, res);		
			}
			else 
			{
				log.info("Not inserted");

		
					
				
			}	
	}
}
