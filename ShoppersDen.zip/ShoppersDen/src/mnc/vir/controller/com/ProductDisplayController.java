package mnc.vir.controller.com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.bean.Item;
import mnc.vir.utility.Order;

public class ProductDisplayController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	
            throws ServletException, IOException {
		Logger log=Logger.getLogger(ProductDisplayController.class);
		PropertyConfigurator.configure("log4j.properties");
		 HttpSession session = req.getSession();
		 Order o=(Order) session.getAttribute("order");
		 System.out.println(o);
    String id=req.getParameter("id");
	log.info(id);
    String cost=req.getParameter("cost");
    int cost1=Integer.parseInt(cost);
	log.info(cost);
    String type=req.getParameter("type");
	log.info(type);
       Item i=new Item();
       i.setCost(cost1);
       i.setIname(id);
     
       o.addProduct(i);
   
		log.info(i);
		log.info(o);
       session.setAttribute("order", o);
       RequestDispatcher requestDispatcher = req.getRequestDispatcher("listitems.jsp?id="+type);
       requestDispatcher.forward(req, res);
       
         
	}

}


