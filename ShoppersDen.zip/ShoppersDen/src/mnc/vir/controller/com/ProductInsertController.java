package mnc.vir.controller.com;





import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



import mnc.vir.service.com.ShoppersService;



public class ProductInsertController extends HttpServlet {

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Logger log=Logger.getLogger(ProductInsertController.class);
		PropertyConfigurator.configure("log4j.properties");
		PrintWriter pw = res.getWriter();
		ShoppersService ss=new ShoppersService();
		
	
		res.setContentType("text/html");
		String s1=	req.getParameter("pid");
		log.info(s1);
		String s2=	req.getParameter("type");
		
		String s3=	req.getParameter("cost");
		
		int i2=Integer.parseInt(s3);
		
		int l=0;
		l=ss.insert(s1,s2,i2);
		if(l!=0){
			RequestDispatcher r=req.getRequestDispatcher("adminlinks.jsp")	;
			pw.println("product added sucessfully");
	    	r.include(req, res);	
		}
	
	}

}
