package mnc.vir.controller.com;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import mnc.vir.bean.Customer;

import mnc.vir.service.com.ShoppersService;
import mnc.vir.utility.Order;



public class UserSigninController extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Logger log=Logger.getLogger(AdminLoginController.class);
		PropertyConfigurator.configure("log4j.properties"); 
		PrintWriter p=res.getWriter();
		 HttpSession session = req.getSession();
		 Order o=new Order();
		 Customer c = new Customer();
		 log.info(o);
		 session.setAttribute("order", o);
		 session.setAttribute("customer", c);
		String s1=req.getParameter("uname");
		ShoppersService ss=new ShoppersService();
		String s2=req.getParameter("psw");
		HttpSession s=req.getSession();
		s.setAttribute("uname", s1);
		String a = (String) s.getAttribute("uname");
      	try {
				if(ss.signin(s1, s2)==1) {
				RequestDispatcher r=req.getRequestDispatcher("userlinks.jsp");
				log.info("Signin Sucessfull");
				r.forward(req, res);
				}
				else {
				p.println("<b style='color:red'>invaliad username and password</b>");
					RequestDispatcher r=req.getRequestDispatcher("UserSignin.html")	;
					p.println("Signin failed");
					log.info("Signin failed  ");
					r.include(req, res);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				log.fatal(e);
				
			}
        		

	}

}
