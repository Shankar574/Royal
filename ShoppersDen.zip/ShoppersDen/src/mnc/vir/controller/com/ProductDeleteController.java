 package mnc.vir.controller.com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import mnc.vir.dao.com.ProductDeletedao;



public class ProductDeleteController extends HttpServlet {
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Logger log=Logger.getLogger(ProductDeleteController.class);
		PropertyConfigurator.configure("log4j.properties");
		int count=0;
		PrintWriter p = res.getWriter();
		String s1=req.getParameter("pid");
		log.info(s1);
		ProductDeletedao d=new ProductDeletedao();
		try {
			count=d.delete(s1);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			log.fatal(e);
		}
	
		RequestDispatcher r=req.getRequestDispatcher("adminlinks.jsp");
	    p.println("product deleted sucessfully");
	    r.forward(req, res);	
		
		
	}

}
