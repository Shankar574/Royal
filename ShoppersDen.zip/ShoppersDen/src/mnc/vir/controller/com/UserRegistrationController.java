package mnc.vir.controller.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mnc.vir.bean.Customer;

import mnc.vir.service.com.ShoppersService;
public class UserRegistrationController extends HttpServlet {
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter p = res.getWriter();
		Customer c=new Customer();
		ShoppersService ss=new ShoppersService();
	
		res.setContentType("text/html");
	
	String s1=	req.getParameter("name");
	System.out.println(s1);
	String s2=	req.getParameter("email");
			String s3=	req.getParameter("mobile");
			System.out.println(s3);
			Double a = Double.parseDouble(s3);
			System.out.println(a);
			String s4=req.getParameter("addr");
			String s5=req.getParameter("password");
			String s6=req.getParameter("userid");
			
c.setUserid(s6);
c.setAddr(s4);
c.setEmail(s2);
c.setName(s1);
c.setPassword(s5);
c.setMobile(a);
int b=ss.insert(c);
if (b==1){

	RequestDispatcher r=req.getRequestDispatcher("UserSignin.html")	;
	p.println("user Registered sucessfully");
	r.include(req, res);
}
else if(b==3){
	System.out.println(" not inserted "); 
	p.println("this user id already register");
	RequestDispatcher r=req.getRequestDispatcher("UserRegister1.html")	;
	r.include(req, res);		
}
else 
{
	System.out.println(" not inserted "); 
		
	
}

}
	}